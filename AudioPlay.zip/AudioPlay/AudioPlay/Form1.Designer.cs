﻿namespace AudioPlay
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.toolStripContainer1 = new System.Windows.Forms.ToolStripContainer();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.position_tb = new System.Windows.Forms.TrackBar();
            this.file_lbl = new System.Windows.Forms.Label();
            this.time_lbl = new System.Windows.Forms.Label();
            this.volume_lbl = new System.Windows.Forms.Label();
            this.volume_tb = new System.Windows.Forms.TrackBar();
            this.stop_bt = new System.Windows.Forms.Button();
            this.play_bt = new System.Windows.Forms.Button();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.toolStripLabel1 = new System.Windows.Forms.ToolStripLabel();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.chose_file_bt = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.exit_bt = new System.Windows.Forms.ToolStripButton();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.toolStripContainer1.ContentPanel.SuspendLayout();
            this.toolStripContainer1.TopToolStripPanel.SuspendLayout();
            this.toolStripContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.position_tb)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.volume_tb)).BeginInit();
            this.toolStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // toolStripContainer1
            // 
            // 
            // toolStripContainer1.ContentPanel
            // 
            this.toolStripContainer1.ContentPanel.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("toolStripContainer1.ContentPanel.BackgroundImage")));
            this.toolStripContainer1.ContentPanel.Controls.Add(this.button2);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.button1);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.position_tb);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.file_lbl);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.time_lbl);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.volume_lbl);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.volume_tb);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.stop_bt);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.play_bt);
            this.toolStripContainer1.ContentPanel.Size = new System.Drawing.Size(634, 252);
            this.toolStripContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.toolStripContainer1.Location = new System.Drawing.Point(0, 0);
            this.toolStripContainer1.Name = "toolStripContainer1";
            this.toolStripContainer1.Size = new System.Drawing.Size(634, 279);
            this.toolStripContainer1.TabIndex = 0;
            this.toolStripContainer1.Text = "toolStripContainer1";
            // 
            // toolStripContainer1.TopToolStripPanel
            // 
            this.toolStripContainer1.TopToolStripPanel.Controls.Add(this.toolStrip1);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Transparent;
            this.button2.FlatAppearance.BorderSize = 0;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button2.Location = new System.Drawing.Point(389, 169);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(60, 23);
            this.button2.TabIndex = 11;
            this.button2.Text = "10с  >>";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Transparent;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button1.Location = new System.Drawing.Point(196, 169);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(60, 23);
            this.button1.TabIndex = 10;
            this.button1.Text = "<<  10с";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // position_tb
            // 
            this.position_tb.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.position_tb.Location = new System.Drawing.Point(16, 114);
            this.position_tb.Maximum = 100;
            this.position_tb.Name = "position_tb";
            this.position_tb.Size = new System.Drawing.Size(600, 45);
            this.position_tb.TabIndex = 9;
            this.position_tb.TickStyle = System.Windows.Forms.TickStyle.None;
            this.position_tb.MouseDown += new System.Windows.Forms.MouseEventHandler(this.position_tb_MouseDown);
            this.position_tb.MouseUp += new System.Windows.Forms.MouseEventHandler(this.position_tb_MouseUp);
            // 
            // file_lbl
            // 
            this.file_lbl.AutoSize = true;
            this.file_lbl.BackColor = System.Drawing.Color.Transparent;
            this.file_lbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.file_lbl.Location = new System.Drawing.Point(13, 28);
            this.file_lbl.Name = "file_lbl";
            this.file_lbl.Size = new System.Drawing.Size(126, 18);
            this.file_lbl.TabIndex = 8;
            this.file_lbl.Text = "Файл не выбран.";
            // 
            // time_lbl
            // 
            this.time_lbl.AutoSize = true;
            this.time_lbl.BackColor = System.Drawing.Color.Transparent;
            this.time_lbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.time_lbl.Location = new System.Drawing.Point(524, 162);
            this.time_lbl.Name = "time_lbl";
            this.time_lbl.Size = new System.Drawing.Size(92, 18);
            this.time_lbl.TabIndex = 7;
            this.time_lbl.Text = "00:00 / 00:00";
            // 
            // volume_lbl
            // 
            this.volume_lbl.AutoSize = true;
            this.volume_lbl.BackColor = System.Drawing.Color.Transparent;
            this.volume_lbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.volume_lbl.Location = new System.Drawing.Point(145, 28);
            this.volume_lbl.Name = "volume_lbl";
            this.volume_lbl.Size = new System.Drawing.Size(122, 18);
            this.volume_lbl.TabIndex = 6;
            this.volume_lbl.Text = "Громкость: 50%";
            // 
            // volume_tb
            // 
            this.volume_tb.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.volume_tb.Location = new System.Drawing.Point(148, 49);
            this.volume_tb.Maximum = 100;
            this.volume_tb.Name = "volume_tb";
            this.volume_tb.Size = new System.Drawing.Size(157, 45);
            this.volume_tb.TabIndex = 5;
            this.volume_tb.TickStyle = System.Windows.Forms.TickStyle.None;
            this.volume_tb.Value = 50;
            this.volume_tb.Scroll += new System.EventHandler(this.volume_tb_Scroll);
            // 
            // stop_bt
            // 
            this.stop_bt.BackColor = System.Drawing.Color.Transparent;
            this.stop_bt.FlatAppearance.BorderSize = 0;
            this.stop_bt.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.stop_bt.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.stop_bt.Image = ((System.Drawing.Image)(resources.GetObject("stop_bt.Image")));
            this.stop_bt.Location = new System.Drawing.Point(337, 162);
            this.stop_bt.Name = "stop_bt";
            this.stop_bt.Size = new System.Drawing.Size(46, 35);
            this.stop_bt.TabIndex = 4;
            this.stop_bt.UseVisualStyleBackColor = false;
            this.stop_bt.Click += new System.EventHandler(this.pause_bt_Click);
            // 
            // play_bt
            // 
            this.play_bt.BackColor = System.Drawing.Color.Transparent;
            this.play_bt.FlatAppearance.BorderSize = 0;
            this.play_bt.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.play_bt.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.play_bt.Image = ((System.Drawing.Image)(resources.GetObject("play_bt.Image")));
            this.play_bt.Location = new System.Drawing.Point(262, 162);
            this.play_bt.Name = "play_bt";
            this.play_bt.Size = new System.Drawing.Size(47, 35);
            this.play_bt.TabIndex = 3;
            this.play_bt.UseVisualStyleBackColor = false;
            this.play_bt.Click += new System.EventHandler(this.play_bt_Click);
            // 
            // toolStrip1
            // 
            this.toolStrip1.Dock = System.Windows.Forms.DockStyle.None;
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripLabel1,
            this.toolStripSeparator1,
            this.chose_file_bt,
            this.toolStripSeparator2,
            this.exit_bt});
            this.toolStrip1.Location = new System.Drawing.Point(3, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(291, 27);
            this.toolStrip1.TabIndex = 0;
            // 
            // toolStripLabel1
            // 
            this.toolStripLabel1.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.toolStripLabel1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.toolStripLabel1.Name = "toolStripLabel1";
            this.toolStripLabel1.Size = new System.Drawing.Size(98, 24);
            this.toolStripLabel1.Text = "Аудио плеер";
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 27);
            // 
            // chose_file_bt
            // 
            this.chose_file_bt.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.chose_file_bt.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.chose_file_bt.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.chose_file_bt.Image = ((System.Drawing.Image)(resources.GetObject("chose_file_bt.Image")));
            this.chose_file_bt.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.chose_file_bt.Name = "chose_file_bt";
            this.chose_file_bt.Size = new System.Drawing.Size(112, 24);
            this.chose_file_bt.Text = "Выбрать файл";
            this.chose_file_bt.Click += new System.EventHandler(this.chose_file_bt_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 27);
            // 
            // exit_bt
            // 
            this.exit_bt.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.exit_bt.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.exit_bt.ForeColor = System.Drawing.Color.Red;
            this.exit_bt.Image = ((System.Drawing.Image)(resources.GetObject("exit_bt.Image")));
            this.exit_bt.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.exit_bt.Name = "exit_bt";
            this.exit_bt.Size = new System.Drawing.Size(57, 24);
            this.exit_bt.Text = "Выход";
            this.exit_bt.Click += new System.EventHandler(this.exit_bt_Click);
            // 
            // timer1
            // 
            this.timer1.Interval = 500;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.ClientSize = new System.Drawing.Size(634, 279);
            this.Controls.Add(this.toolStripContainer1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.Text = "Audio Player";
            this.toolStripContainer1.ContentPanel.ResumeLayout(false);
            this.toolStripContainer1.ContentPanel.PerformLayout();
            this.toolStripContainer1.TopToolStripPanel.ResumeLayout(false);
            this.toolStripContainer1.TopToolStripPanel.PerformLayout();
            this.toolStripContainer1.ResumeLayout(false);
            this.toolStripContainer1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.position_tb)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.volume_tb)).EndInit();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ToolStripContainer toolStripContainer1;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripLabel toolStripLabel1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripButton chose_file_bt;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripButton exit_bt;
        private System.Windows.Forms.Button play_bt;
        private System.Windows.Forms.Label volume_lbl;
        private System.Windows.Forms.TrackBar volume_tb;
        private System.Windows.Forms.Button stop_bt;
        private System.Windows.Forms.TrackBar position_tb;
        private System.Windows.Forms.Label file_lbl;
        private System.Windows.Forms.Label time_lbl;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
    }
}

