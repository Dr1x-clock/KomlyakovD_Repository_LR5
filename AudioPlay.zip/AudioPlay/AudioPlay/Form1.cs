﻿using System;
using System.Windows.Forms;
using NAudio.Wave;

namespace AudioPlay
{
    public partial class Form1 : Form
    {
        private AudioFileReader audioFile;
        private WaveOutEvent outputDevice;
        private string currentFilePath;
        private bool isDragging = false;

        public Form1()
        {
            InitializeComponent();

            volume_tb.Minimum = 0;
            volume_tb.Maximum = 100;
            volume_tb.Value = 50;

            position_tb.Minimum = 0;
            position_tb.Maximum = 100;

            timer1.Interval = 500;
        }

        private void chose_file_bt_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "Audio Files|*.mp3;*.wav";

            if (ofd.ShowDialog() == DialogResult.OK)
            {
                currentFilePath = ofd.FileName;
                file_lbl.Text = System.IO.Path.GetFileName(currentFilePath);

                if (outputDevice != null)
                {
                    outputDevice.Stop();
                    outputDevice.Dispose();
                }

                audioFile = new AudioFileReader(currentFilePath);
                outputDevice = new WaveOutEvent();
                outputDevice.Init(audioFile);

                audioFile.Volume = volume_tb.Value / 100f;

                timer1.Start();
                outputDevice.Play();
            }
        }

        private void play_bt_Click(object sender, EventArgs e)
        {
            if (outputDevice != null)
            {
                outputDevice.Play();
            }
        }

        private void pause_bt_Click(object sender, EventArgs e)
        {
            if (outputDevice != null)
            {
                outputDevice.Pause();
            }
        }

        private void volume_tb_Scroll(object sender, EventArgs e)
        {
            if (audioFile != null)
            {
                audioFile.Volume = volume_tb.Value / 100f;
                volume_lbl.Text = "Volume: " + volume_tb.Value + "%";
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (audioFile == null)
                return;

            TimeSpan currentTime = audioFile.CurrentTime;
            TimeSpan totalTime = audioFile.TotalTime;

            if (!isDragging)
            {
                time_lbl.Text = $"{currentTime:mm\\:ss} / {totalTime:mm\\:ss}";

                if (totalTime.TotalSeconds > 0)
                {
                    position_tb.Value = (int)
                        (currentTime.TotalSeconds / totalTime.TotalSeconds * 100);
                }
            }

            if (currentTime >= totalTime && totalTime.TotalSeconds > 0)
            {
                audioFile.CurrentTime = TimeSpan.Zero;
                outputDevice.Play();
            }
        }

        private void position_tb_MouseDown(object sender, MouseEventArgs e)
        {
            isDragging = true;
        }

        private void position_tb_MouseUp(object sender, MouseEventArgs e)
        {
            if (audioFile != null)
            {
                double percentage = position_tb.Value / 100.0;
                double newPosition = audioFile.TotalTime.TotalSeconds * percentage;
                audioFile.CurrentTime = TimeSpan.FromSeconds(newPosition);
            }

            isDragging = false;
        }

        private void exit_bt_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            outputDevice?.Stop();
            outputDevice?.Dispose();
            audioFile?.Dispose();
            base.OnFormClosing(e);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (audioFile == null)
                return;

            double newPosition = audioFile.CurrentTime.TotalSeconds - 10;

            if (newPosition < 0)
                newPosition = 0;

            audioFile.CurrentTime = TimeSpan.FromSeconds(newPosition);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (audioFile == null)
                return;

            double newPosition = audioFile.CurrentTime.TotalSeconds + 10;

            if (newPosition > audioFile.TotalTime.TotalSeconds)
                newPosition = audioFile.TotalTime.TotalSeconds;

            audioFile.CurrentTime = TimeSpan.FromSeconds(newPosition);
        }
    }
}